package com.ecom.Controller;

import com.ecom.Entity.CartItem;
import com.ecom.Service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class CartController {

    @Autowired
    private CartService cartService;

    @PostMapping("/add/{userId}/{productId}")
    public ResponseEntity<CartItem> addProductToCart(@PathVariable Long userId, @PathVariable Long productId, @RequestParam(required = false, defaultValue = "1") Integer quantity) {
    	CartItem cartItem = cartService.addProductToCart(userId, productId, quantity);
        return ResponseEntity.ok(cartItem);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<List<CartItem>> getCartByUser(@PathVariable Long userId) {
        List<CartItem> cartItems = (List<CartItem>) cartService.getCartByUser(userId);
        return ResponseEntity.ok(cartItems);
    }

    @PutMapping("/increase/{userId}/{productId}")
    public ResponseEntity<CartItem> increaseQuantity(@PathVariable Long userId, @PathVariable Long productId) {
        CartItem cartItem = cartService.increaseQuantity(userId, productId);
        return ResponseEntity.ok(cartItem);
    }

    @PutMapping("/decrease/{userId}/{productId}")
    public ResponseEntity<CartItem> decreaseQuantity(@PathVariable Long userId, @PathVariable Long productId) {
        CartItem cartItem = cartService.decreaseQuantity(userId, productId);
        return ResponseEntity.ok(cartItem);
    }

    @DeleteMapping("/remove/{userId}/{cartItemId}")
    public ResponseEntity<Void> removeProductFromCart(@PathVariable Long userId, @PathVariable Long cartItemId) {
        cartService.removeItemFromCart(userId, cartItemId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/total/{userId}")
    public ResponseEntity<Double> getTotalPrice(@PathVariable Long userId) {
        Double totalPrice = cartService.getTotalPrice(userId);
        return ResponseEntity.ok(totalPrice);
    }

    @DeleteMapping("/clear/{userId}")
    public ResponseEntity<Void> clearCart(@PathVariable Long userId) {
        cartService.clearCart(userId);
        return ResponseEntity.noContent().build();
    }
    
    @PutMapping("/setQuantity/{userId}/{productId}")
    public ResponseEntity<CartItem> setQuantity(@PathVariable Long userId, @PathVariable Long productId, @RequestParam Integer quantity) {
        CartItem updatedCartItem = cartService.setQuantity(userId, productId, quantity);
        return ResponseEntity.ok(updatedCartItem);
    }
}
