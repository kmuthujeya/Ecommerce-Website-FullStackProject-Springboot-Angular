package com.ecom.Repository;

import com.ecom.Entity.Orders;
import com.ecom.Entity.User;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Orders, Long> {
    
    // Find all orders by a specific user
    List<Orders> findByUser(User user);
    
    // Find orders by status
    List<Orders> findByOrderStatus(String orderStatus);
    
    // Custom query to find orders within a date range (optional)
    List<Orders> findByOrderDateBetween(LocalDate startDate, LocalDate endDate);
    
    Page<Orders> findAll(Pageable pageable);
}
