package com.ecom.Exception;

public class ConstraintViolationException extends RuntimeException {
    public ConstraintViolationException(String message) {
  	  super(message);
  } 

}
