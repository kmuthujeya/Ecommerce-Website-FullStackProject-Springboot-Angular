package com.ecom.Entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.util.List;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @NotBlank(message = "Username is mandatory")
    @Pattern(regexp = "^[A-Za-z]+$", message = "Username must contain only alphabets")
    @Size(min = 5, max = 15, message = "Username must be between 5 and 15 characters")
    @Column(name="username", unique = true)
    private String username;

    @NotBlank(message = "Password is mandatory")
    @Size(min = 8, message = "Password must be at least 8 characters")
    private String password;

    @NotBlank(message = "Role is mandatory")
    private String role;

    @NotNull(message = "Phone number is mandatory")
    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be a 10-digit number")
    @Column(name = "phoneNumber", unique = true)
    private String phoneNumber;

    @NotBlank(message = "Email is mandatory")
    @Email(message = "Email should contain a valid '@' character and domain")
    @Column(name = "email", unique = true)
    private String email;

    @OneToMany(mappedBy = "user")
    @JsonManagedReference("user-cartItem")
    private List<CartItem> cartItems;

    // Getters and Setters...

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }
}
