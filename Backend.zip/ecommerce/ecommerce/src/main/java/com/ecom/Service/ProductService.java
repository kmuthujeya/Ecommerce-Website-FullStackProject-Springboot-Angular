package com.ecom.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.ecom.Entity.Product;
import com.ecom.Exception.ProductNotFoundException;
import com.ecom.Repository.ProductRepository;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    public Page<Product> getAllProducts(Pageable pageable) {
        try {
            return productRepository.findAll(pageable);
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all products: " + e.getMessage());
        }
    }

    public Product addProduct(Product product) {
        try {
            return productRepository.save(product);
        } catch (Exception e) {
            throw new RuntimeException("Error adding new product: " + e.getMessage());
        }
    }

    public Optional<Product> getProductDetailsById(Long productId) {
        return productRepository.findById(productId);
    }

    
    public Product updateProductDetails(Long productId, Product updatedProduct) {
        try {
            Product existingProduct = productRepository.findById(productId)
                    .orElseThrow(() -> new ProductNotFoundException("Product not found with id: " + productId));

            existingProduct.setProductName(updatedProduct.getProductName());
            existingProduct.setProductDescription(updatedProduct.getProductDescription());
            existingProduct.setProductActualPrice(updatedProduct.getProductActualPrice());
            existingProduct.setProductDiscountedPrice(updatedProduct.getProductDiscountedPrice());
            existingProduct.setImageUrls(updatedProduct.getImageUrls());

            return productRepository.save(existingProduct);
        } catch (ProductNotFoundException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("Error updating product details: " + e.getMessage());
        }
    }

    public void deleteProductDetails(Long productId) {
        try {
            // Check if the product exists in the database
            if (!productRepository.existsById(productId)) {
                throw new ProductNotFoundException("Product not found with id: " + productId);
            }

            // Delete the product
            productRepository.deleteById(productId);
            
        } catch (ProductNotFoundException e) {
            // Handle the case where the product is not found
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found", e);
        } catch (DataIntegrityViolationException e) {
            // Handle foreign key constraint violation
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Product cannot be deleted due to foreign key constraint", e);
        } catch (Exception e) {
            // Handle any other errors
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error deleting product", e);
        }
    }

    
    public Page<Product> searchProducts(String keyword, Pageable pageable) {
        return productRepository.searchByKeyword(keyword, pageable);
    }
}
